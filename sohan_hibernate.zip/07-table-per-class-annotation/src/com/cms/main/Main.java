package com.cms.main;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.bean.Address;
import com.cms.bean.Contact;
import com.cms.bean.Employee;
import com.cms.bean.Friend;
import com.cms.bean.Relative;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Contact c1 = new Employee("firstName1", 
								 "lastName1", 
								 "email1", 
								 Date.valueOf("2001-01-01"),
								 new Address("city1","country1"),
								 "EMP_CODE-001",
								 "Designation1");
		
		Contact c2 = new Relative("firstName2", 
				 "lastName2", 
				 "email2", 
				 Date.valueOf("2001-07-21"),
				 new Address("city2","country2"),
				 "Relation1");
		
		Contact c3 = new Friend("firstName3", 
				 "lastName3", 
				 "email3", 
				 Date.valueOf("2005-10-10"),
				 new Address("city3","country3"),
				 "PetName1");
			
		c1.setContactId(100);
		c2.setContactId(200);
		c3.setContactId(300);
		
		//configuring hibernate
		Configuration configuration;
		configuration = new Configuration().configure();
		
		SessionFactory sf;
		sf = configuration.buildSessionFactory();
		
		//creating & opening a hibernate session
		Session session;
		session = sf.openSession();
		//above statement creates connection to the DB
		//hibernate session is not thread safe
		//hibernate sets autoCommit mode to false
		//transactions are compulsory in hibernate
		
		Transaction tx;
		
		tx = session.beginTransaction();
		
		session.persist(c1);
		session.saveOrUpdate(c2);
		session.save(c3);
		
		
		tx.commit();
		
		session.close();
		sf.close();
				
	}

}
