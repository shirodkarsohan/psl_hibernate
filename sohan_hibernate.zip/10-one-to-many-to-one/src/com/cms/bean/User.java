package com.cms.bean;

import java.util.HashSet;
import java.util.Set;

public class User {
	private int userId;
	private String useranme;
	private Set<Contact> contacts = new HashSet<Contact>();
	
	public User() {
		super();
	}
	
	public User(String useranme) {
		super();
		this.useranme = useranme;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUseranme() {
		return useranme;
	}
	public void setUseranme(String useranme) {
		this.useranme = useranme;
	}
	public Set<Contact> getContacts() {
		return contacts;
	}
	public void setContacts(Set<Contact> contacts) {
		this.contacts = contacts;
	}
	
	
}
