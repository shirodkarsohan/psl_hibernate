package com.cms.main;

import java.sql.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.bean.Address;
import com.cms.bean.Contact;
import com.cms.bean.Profile;
import com.cms.bean.Qualification;
import com.cms.bean.User;

public class Main {
	public static void main(String[] args) {
		Contact c1 = new Contact("firstName1", "lastName1", "email1", Date
				.valueOf("2010-03-03"), new Address("Margao1", "India"));
		Contact c2 = new Contact("firstName2", "lastName2", "email2", Date
				.valueOf("2015-09-03"), new Address("Madgao2", "India"));
		Contact c3 = new Contact("firstName3", "lastName3", "email3", Date
				.valueOf("2013-04-03"), new Address("Margao3", "India"));
		Contact c4 = new Contact("firstName4", "lastName4", "email4", Date
				.valueOf("2009-06-03"), new Address("Margao4", "India"));
		Contact c5 = new Contact("firstName5", "lastName5", "email5", Date
				.valueOf("2011-09-03"), new Address("Margao5", "India"));
		Contact c6 = new Contact("firstName6", "lastName6", "email6", Date
				.valueOf("2012-02-03"), new Address("Margao6", "India"));
		Contact c7 = new Contact("firstName7", "lastName7", "email7", Date
				.valueOf("2014-03-03"), new Address("Margao7", "India"));
		Contact c8 = new Contact("firstName8", "lastName8", "email8", Date
				.valueOf("2010-09-03"), new Address("Margao8", "India"));
		Contact c9 = new Contact("firstName9", "lastName9", "email9", Date
				.valueOf("2017-01-03"), new Address("Margao9", "India"));
		Contact c10 = new Contact("firstName10", "lastName10", "email10", Date
				.valueOf("2016-03-03"), new Address("Margao10", "India10"));

		User u1 = new User("A1");
		User u2 = new User("B1");
		User u3 = new User("C1");
		User u4 = new User("D1");
		User u5 = new User("E1");

		Profile p1 = new Profile("school1", "College1");
		Profile p2 = new Profile("school1", "College1");
		Profile p3 = new Profile("school1", "College1");
		Profile p4 = new Profile("school1", "College1");
		Profile p5 = new Profile("school1", "College1");
		Profile p6 = new Profile("school1", "College1");
		Profile p7 = new Profile("school1", "College1");
		Profile p8 = new Profile("school1", "College1");
		Profile p9 = new Profile("school1", "College1");
		Profile p10 = new Profile("school1", "College1");

		Qualification bcom = new Qualification("B.Com.");
		Qualification ba = new Qualification("B.A.");
		Qualification be = new Qualification("B.E.");
		Qualification btech = new Qualification("B.Tech.");

		p1.addQualification(bcom);
		p1.addQualification(ba);

		p2.addQualification(be);
		p2.addQualification(ba);
		p2.addQualification(btech);

		p3.addQualification(be);
		p3.addQualification(btech);

		p4.addQualification(ba);
		p4.addQualification(btech);
		p4.addQualification(bcom);

		p5.addQualification(ba);
		p5.addQualification(bcom);

		p6.addQualification(ba);
		p6.addQualification(be);
		p6.addQualification(bcom);

		p7.addQualification(btech);
		p7.addQualification(be);

		p8.addQualification(ba);
		p8.addQualification(bcom);

		p9.addQualification(btech);
		p9.addQualification(be);
		
		p10.addQualification(ba);
		p10.addQualification(bcom);

		c1.addProfile(p1);
		c2.addProfile(p2);
		c3.addProfile(p3);
		c4.addProfile(p4);
		c5.addProfile(p5);
		c6.addProfile(p6);
		c7.addProfile(p7);
		c8.addProfile(p8);
		c9.addProfile(p9);
		c10.addProfile(p10);

		u1.addContact(c1);
		u1.addContact(c2);

		u2.addContact(c3);
		u2.addContact(c4);
		u2.addContact(c5);

		u3.addContact(c6);

		u4.addContact(c7);
		u4.addContact(c8);

		u5.addContact(c9);
		u5.addContact(c10);

		SessionFactory sFact = new Configuration().configure()
				.buildSessionFactory();
		Session session = sFact.openSession();

		Transaction tx = session.beginTransaction();
		session.save(u1);
		session.save(u2);
		session.save(u3);
		session.save(u4);
		session.save(u5);
		tx.commit();

		session.clear();
		
		/*User ru;
		ru = (User) session.get(User.class, new Integer(1));
		
		//System.out.println(ru.getContacts().size());
		for(Contact c : ru.getContacts() ){
			System.out.println(c.getEmail());
		}
		System.out.println(ru.getUserId());
		System.out.println(ru.getUsername());*/
		Query query = session.createQuery("from User"); //select * from tbl_users
		
		List<User> users = query.list();
		
		//(n+1) selects
		for(User u : users){
			System.out.println(u.getUsername());
			for(Contact c : u.getContacts()){
				System.out.println(c.getEmail());
			}
		}
		
		
		session.close();
		sFact.close();

	}

}
