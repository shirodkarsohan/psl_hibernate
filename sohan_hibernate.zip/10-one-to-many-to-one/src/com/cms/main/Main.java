package com.cms.main;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.bean.Address;
import com.cms.bean.Contact;
import com.cms.bean.User;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		User u1 = new User("Username1");
		User u2 = new User("Username2");
		User u3 = new User("Username3");
		User u4 = new User("Username4");
		User u5 = new User("Username5");
		
		Contact c1 = new Contact("firstName1", 
								 "lastName1", 
								 "email1", 
								 Date.valueOf("2001-01-01"),
								 new Address("city1","country1"));
		
		Contact c2 = new Contact("firstName2", 
				 "lastName2", 
				 "email2", 
				 Date.valueOf("2001-07-21"),
				 new Address("city2","country2"));
		
		Contact c3 = new Contact("firstName3", 
				 "lastName3", 
				 "email3", 
				 Date.valueOf("2005-10-10"),
				 new Address("city3","country3"));
		
		Contact c4 = new Contact("firstName4", 
				 "lastName4", 
				 "email4", 
				 Date.valueOf("2001-11-01"),
				 new Address("city4","country4"));
		
		Contact c5 = new Contact("firstName5", 
				 "lastName5", 
				 "email5", 
				 Date.valueOf("2005-10-10"),
				 new Address("city5","country5"));
		
		Contact c6 = new Contact("firstName6", 
				 "lastName6", 
				 "email6", 
				 Date.valueOf("2001-11-01"),
				 new Address("city6","country6"));
		
		Contact c7 = new Contact("firstName7", 
				 "lastName7", 
				 "email7", 
				 Date.valueOf("1998-04-23"),
				 new Address("city7","country7"));
		
		Contact c8 = new Contact("firstName8", 
				 "lastName8", 
				 "email8", 
				 Date.valueOf("1998-04-23"),
				 new Address("city8","country8"));
		
		Contact c9 = new Contact("firstName9", 
				 "lastName9", 
				 "email9", 
				 Date.valueOf("2011-01-02"),
				 new Address("city9","country9"));
		
		Contact c10 = new Contact("firstName10", 
				 "lastName10", 
				 "email10", 
				 Date.valueOf("2011-01-02"),
				 new Address("city10","country10"));
		
		u1.getContacts().add(c1);
		u1.getContacts().add(c2);
		c1.setOwner(u1);
		c2.setOwner(u1);
		
		u2.getContacts().add(c3);
		u2.getContacts().add(c4);
		u2.getContacts().add(c5);
		c3.setOwner(u2);
		c4.setOwner(u2);
		c5.setOwner(u2);
		
		u3.getContacts().add(c6);
		c6.setOwner(u3);
		
		u4.getContacts().add(c7);
		u4.getContacts().add(c8);
		c7.setOwner(u4);
		c8.setOwner(u4);
		
		u5.getContacts().add(c9);
		u5.getContacts().add(c10);
		c9.setOwner(u5);
		c10.setOwner(u5);
		
		//configuring hibernate
		Configuration configuration;
		configuration = new Configuration().configure();
		
		SessionFactory sf;
		sf = configuration.buildSessionFactory();
		
		//creating & opening a hibernate session
		Session session;
		session = sf.openSession();
		//above statement creates connection to the DB
		//hibernate session is not thread safe
		//hibernate sets autoCommit mode to false
		//transactions are compulsory in hibernate
		
		Transaction tx;
		tx = session.beginTransaction();
		
		/*
		 * The for-each loops are no longer needed when we specify cascade property in User.hbm.xml
		 */
		session.save(u1);
		/*for(Contact c : u1.getContacts() ){
			session.save(c);
		}*/
		
		session.save(u2);
		/*for(Contact c : u2.getContacts() ){
			session.save(c);
		}*/
		
		session.save(u3);
		/*for(Contact c : u3.getContacts() ){
			session.save(c);
		}*/
		
		session.save(u4);
		/*for(Contact c : u4.getContacts() ){
			session.save(c);
		}*/
		
		session.save(u5);
		/*for(Contact c : u5.getContacts() ){
			session.save(c);
		}*/
		
		tx.commit();
		session.close();
		sf.close();
				
	}

}
