package com.ems.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_answers")
public class Answer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ANSWER_ID")
	private int id;
	private String answerName;
	private String postedBy;
	
	public Answer() {
		// TODO Auto-generated constructor stub
	}
	
	public Answer(String answerName, String postedBy) {
		super();
		this.answerName = answerName;
		this.postedBy = postedBy;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAnswerName() {
		return answerName;
	}
	public void setAnswerName(String answerName) {
		this.answerName = answerName;
	}
	public String getPostedBy() {
		return postedBy;
	}
	public void setPostedBy(String postedBy) {
		this.postedBy = postedBy;
	}
}
