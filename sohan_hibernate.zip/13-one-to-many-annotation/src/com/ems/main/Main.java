package com.ems.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ems.bean.Answer;
import com.ems.bean.Question;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Question q1 = new Question("question1");
		Question q2 = new Question("question2");
		Question q3 = new Question("question3");
		
		Answer a1 = new Answer("answer1", "person1");
		Answer a2 = new Answer("answer2", "person2");
		Answer a3 = new Answer("answer3", "person3");
		Answer a4 = new Answer("answer4", "person4");
		Answer a5 = new Answer("answer5", "person5");
		
		q1.addAnswer(a1);
		q1.addAnswer(a2);
		
		q2.addAnswer(a3);
		
		q3.addAnswer(a4);
		q3.addAnswer(a5);
		
		Configuration configuration;
		configuration = new Configuration().configure();
		
		SessionFactory sf;
		sf = configuration.buildSessionFactory();
		
		Session session;
		session = sf.openSession();
		
		Transaction tx;
		tx = session.beginTransaction();
		
		session.save(q1);
		session.save(q2);
		session.save(q3);
		
		tx.commit();
		session.clear();
		
	}

}
