package com.cms.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.bean.Account;
import com.cms.bean.User;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User u1 = new User("Steven Smith");
		User u2 = new User("George Balley");
		User u3 = new User("Mitchele Starc");
		User u4 = new User("Scott Boland");
		User u5 = new User("Glenn Maxwell");
		
		u1.addAccount(new Account(235.236));
		u1.addAccount(new Account(1000.0));
		
		u2.addAccount(new Account(50000.50));
		
		u3.addAccount(new Account(10.45));
		u3.addAccount(new Account(90.875));
		u3.addAccount(new Account(200.2));
		
		u4.addAccount(new Account(500.00));
		
		//configuring hibernate
		Configuration configuration;
		configuration = new Configuration().configure();
		
		SessionFactory sf;
		sf = configuration.buildSessionFactory();
		
		//creating & opening a hibernate session
		Session session;
		session = sf.openSession();
		//above statement creates connection to the DB
		//hibernate session is not thread safe
		//hibernate sets autoCommit mode to false
		//transactions are compulsory in hibernate
		
		Transaction tx;
		tx = session.beginTransaction();
		
		session.save(u1);
		session.save(u2);
		session.save(u3);
		session.save(u4);
		
		
		tx.commit();
		
		session.close();
		sf.close();
				
	}

}
