package com.cms.bean;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="tbl_contacts")
public class Contact {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int contactId;
	private String firstName, lastName;
	private String email;
	private Date dateOfBirth;
	
	@ElementCollection
	private List<Address> addresses = new ArrayList<Address>();
	
	@ElementCollection
	private Set<String> mobileNumbers = new HashSet<String>();
	/*
	 * Hibernate recommends
	 * 1) data type of the data member should be the interface type
	 * 2) initialize collection at the point of declaration
	 */
	
	
	public Contact() {
		super();
	}


	public Contact(String firstName, String lastName, String email,
			Date dateOfBirth) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.dateOfBirth = dateOfBirth;
	}

	public int getContactId() {
		return contactId;
	}
	public void setContactId(int contactId) {
		this.contactId = contactId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public Set<String> getMobileNumbers() {
		return mobileNumbers;
	}

	public void setMobileNumbers(Set<String> mobileNumbers) {
		this.mobileNumbers = mobileNumbers;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	
	public List<Address> getAddresses() {
		return addresses;
	}
	
	
}
