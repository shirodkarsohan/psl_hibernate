package com.cms.main;

import java.io.File;
import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.bean.Address;
import com.cms.bean.Contact;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Contact c1 = new Contact("firstName1", 
								 "lastName1", 
								 "email1", 
								 Date.valueOf("2001-01-01"),
								 new Address("city1","country1"));
		
		Contact c2 = new Contact("firstName2", 
				 "lastName2", 
				 "email2", 
				 Date.valueOf("2001-07-21"),
				 new Address("city2","country2"));
		
		Contact c3 = new Contact("firstName3", 
				 "lastName3", 
				 "email3", 
				 Date.valueOf("2005-10-10"),
				 new Address("city3","country3"));
		
		Contact c4 = new Contact("firstName4", 
				 "lastName4", 
				 "email4", 
				 Date.valueOf("2001-11-01"),
				 new Address("city4","country4"));
		
		//configuring hibernate
		Configuration configuration;
		configuration = new Configuration().configure();
		
		SessionFactory sf;
		sf = configuration.buildSessionFactory();
		
		//creating & opening a hibernate session
		Session session;
		session = sf.openSession();
		//above statement creates connection to the DB
		//hibernate session is not thread safe
		//hibernate sets autoCommit mode to false
		//transactions are compulsory in hibernate
		
		Transaction tx;
		tx = session.beginTransaction();
		
		session.save(c1);
		session.persist(c2);
		session.saveOrUpdate(c3);
		session.save(c4);
		
		/*Other methods used : 
			* 1) persist()
			* 2) saveOrUpdate()*/
		
		
		
		tx.commit();
		
		session.clear();
		
		Contact rc = (Contact) session.get(Contact.class, new Integer(1));
		
		c1.setFirstName("Sohan Shirodkar");
		c1.setEmail("shirodkarsohan@gmail.com");
		
		tx = session.beginTransaction();
		//session.update(c1);
		/*org.hibernate.NonUniqueObjectException: 
			a different object with the same identifier value was already associated with the session*/
		
		session.merge(c1);
		
		/*persist method cannot be called on detached objects :  
		org.hibernate.PersistentObjectException: detached entity passed to persist: com.cms.bean.Contact
		session.persist(c1);*/
		
		tx.commit();
		//session.clear();
		
		/*Contact retrieveContact = (Contact) session.get(Contact.class, new Integer(2));
		object is fetched from the DB is the seesion.clear() is executed 
		An unsuccessful get will give NullPointerException
		
		System.out.println(retrieveContact.getContactId());
		System.out.println(retrieveContact.getFirstName());
		System.out.println(retrieveContact.getEmail());*/
		
		session.close();
		sf.close();
				
	}

}
